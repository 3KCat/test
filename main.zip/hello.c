#include<stdio.h>

int main(void){
    printf("Hello,C!");
    return 0;
}