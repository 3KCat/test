#include  <stdio.h>

int main() {
    printf("死ねばーか");
    return 0;
}